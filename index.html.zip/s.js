
// ======================================
// COMPUTER LABORATORY EQUIPMENT SYSTEM
// ======================================

// Get HTML elements
const equipmentForm = document.getElementById("equipmentForm");
const equipmentTable = document.getElementById("equipmentTable");

const equipmentId = document.getElementById("equipmentId");
const equipmentName = document.getElementById("equipmentName");
const category = document.getElementById("category");
const quantity = document.getElementById("quantity");
const condition = document.getElementById("condition");
const locationInput = document.getElementById("location");
const purchaseDate = document.getElementById("purchaseDate");
const personInCharge = document.getElementById("personInCharge");

const searchInput = document.getElementById("searchInput");
const conditionFilter = document.getElementById("conditionFilter");
const categoryFilter = document.getElementById("categoryFilter");
const sortFilter = document.getElementById("sortFilter");

const saveButton = document.getElementById("saveButton");
const cancelButton = document.getElementById("cancelButton");
const formTitle = document.getElementById("formTitle");

// Load saved records from browser storage
let equipmentList = JSON.parse(
    localStorage.getItem("computerLabEquipment")
) || [];

// Store the ID of the equipment being edited
let editingId = null;


// ======================================
// SAVE DATA
// ======================================

function saveData() {
    localStorage.setItem(
        "computerLabEquipment",
        JSON.stringify(equipmentList)
    );
}


// ======================================
// PREVENT HTML INJECTION
// ======================================

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, function(character) {
        const replacements = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return replacements[character];
    });
}


// ======================================
// ADD OR UPDATE EQUIPMENT
// ======================================

equipmentForm.addEventListener("submit", function(event) {

    event.preventDefault();

    // Get input values
    const id = equipmentId.value.trim();
    const name = equipmentName.value.trim();
    const selectedCategory = category.value;
    const qty = Number(quantity.value);
    const selectedCondition = condition.value;
    const place = locationInput.value.trim();
    const date = purchaseDate.value;
    const staff = personInCharge.value.trim();

    // Validate quantity
    if (!Number.isSafeInteger(qty) || qty < 1) {
        alert("Please enter a valid quantity.");
        return;
    }

    // Check for duplicate equipment ID
    const duplicate = equipmentList.some(function(item) {
        return item.id.toLowerCase() === id.toLowerCase()
            && item.id !== editingId;
    });

    if (duplicate) {
        alert("Equipment ID already exists!");
        return;
    }

    // Validate required fields
    if (!id || !name || !selectedCategory ||
        !selectedCondition || !place || !date || !staff) {

        alert("Please complete all fields.");
        return;
    }

    // Create equipment record
    const equipment = {
        id: id,
        name: name,
        category: selectedCategory,
        quantity: qty,
        condition: selectedCondition,
        location: place,
        purchaseDate: date,
        personInCharge: staff
    };

    if (editingId !== null) {

        // Update existing record
        const index = equipmentList.findIndex(function(item) {
            return item.id === editingId;
        });

        if (index !== -1) {
            equipmentList[index] = equipment;
        }

        alert("Equipment successfully updated!");

    } else {

        // Add new record
        equipmentList.push(equipment);

        alert("Equipment successfully added!");
    }

    // Save records
    saveData();

    // Reset form
    resetForm();

    // Update display
    displayEquipment();
});


// ======================================
// DISPLAY EQUIPMENT
// ======================================

function displayEquipment() {

    equipmentTable.innerHTML = "";

    // Get search and filter values
    const search = searchInput.value.toLowerCase();
    const selectedCondition = conditionFilter.value;
    const selectedCategory = categoryFilter.value;
    const sorting = sortFilter.value;

    // Filter equipment
    let filteredList = equipmentList.filter(function(item) {

        const matchesSearch =
            item.id.toLowerCase().includes(search) ||
            item.name.toLowerCase().includes(search) ||
            item.category.toLowerCase().includes(search) ||
            item.location.toLowerCase().includes(search) ||
            item.personInCharge.toLowerCase().includes(search);

        const matchesCondition =
            selectedCondition === "" ||
            item.condition === selectedCondition;

        const matchesCategory =
            selectedCategory === "" ||
            item.category === selectedCategory;

        return matchesSearch &&
               matchesCondition &&
               matchesCategory;
    });

    // Sort equipment
    filteredList.sort(function(a, b) {

        if (sorting === "name") {
            return a.name.localeCompare(b.name);
        }

        if (sorting === "quantity") {
            return b.quantity - a.quantity;
        }

        if (sorting === "date") {
            return new Date(b.purchaseDate) -
                   new Date(a.purchaseDate);
        }

        if (sorting === "condition") {
            return a.condition.localeCompare(b.condition);
        }

        return 0;
    });

    // Show equipment records
    filteredList.forEach(function(item) {

        let statusClass = "";

        if (item.condition === "Working") {
            statusClass = "status-working";
        } else if (item.condition === "Under Maintenance") {
            statusClass = "status-maintenance";
        } else {
            statusClass = "status-damaged";
        }

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${escapeHTML(item.id)}</td>
            <td>${escapeHTML(item.name)}</td>
            <td>${escapeHTML(item.category)}</td>
            <td>${item.quantity}</td>

            <td>
                <span class="status ${statusClass}">
                    ${escapeHTML(item.condition)}
                </span>
            </td>

            <td>${escapeHTML(item.location)}</td>
            <td>${escapeHTML(item.purchaseDate)}</td>
            <td>${escapeHTML(item.personInCharge)}</td>

            <td>
                <button class="edit-btn"
                    onclick="editEquipment('${encodeURIComponent(item.id)}')">
                    Edit
                </button>

                <button class="delete-btn"
                    onclick="deleteEquipment('${encodeURIComponent(item.id)}')">
                    Delete
                </button>
            </td>
        `;

        equipmentTable.appendChild(row);
    });

    // Show empty message
    if (filteredList.length === 0) {
        equipmentTable.innerHTML = `
            <tr>
                <td colspan="9" style="text-align:center;">
                    No equipment records found.
                </td>
            </tr>
        `;
    }

    // Update record count
    document.getElementById("recordCount").textContent =
        "Showing " + filteredList.length + " records";

    // Update dashboard
    updateDashboard();
}


// ======================================
// DASHBOARD CALCULATIONS
// ======================================

function updateDashboard() {

    // Calculate total quantities
    const total = equipmentList.reduce(function(sum, item) {
        return sum + item.quantity;
    }, 0);

    // Calculate working equipment
    const working = equipmentList.reduce(function(sum, item) {
        return sum + (
            item.condition === "Working" ? item.quantity : 0
        );
    }, 0);

    // Calculate maintenance equipment
    const maintenance = equipmentList.reduce(function(sum, item) {
        return sum + (
            item.condition === "Under Maintenance" ?
            item.quantity : 0
        );
    }, 0);

    // Calculate damaged equipment
    const damaged = equipmentList.reduce(function(sum, item) {
        return sum + (
            item.condition === "Damaged" ? item.quantity : 0
        );
    }, 0);

    // Display calculations
    document.getElementById("totalEquipment").textContent = total;

    document.getElementById("workingCount").textContent = working;

    document.getElementById("maintenanceCount").textContent =
        maintenance;

    document.getElementById("damagedCount").textContent = damaged;
}


// ======================================
// EDIT EQUIPMENT
// ======================================

function editEquipment(encodedId) {

    const id = decodeURIComponent(encodedId);

    const item = equipmentList.find(function(equipment) {
        return equipment.id === id;
    });

    if (!item) return;

    // Put existing information in the form
    equipmentId.value = item.id;
    equipmentName.value = item.name;
    category.value = item.category;
    quantity.value = item.quantity;
    condition.value = item.condition;
    locationInput.value = item.location;
    purchaseDate.value = item.purchaseDate;
    personInCharge.value = item.personInCharge;

    // Remember original ID
    editingId = item.id;

    // Change form title and button
    formTitle.textContent = "Edit Equipment";
    saveButton.textContent = "Update Equipment";

    cancelButton.classList.remove("hidden");

    // Scroll to form
    equipmentForm.scrollIntoView({
        behavior: "smooth"
    });
}


// ======================================
// DELETE EQUIPMENT
// ======================================

function deleteEquipment(encodedId) {

    const id = decodeURIComponent(encodedId);

    const confirmDelete = confirm(
        "Are you sure you want to delete this equipment record?"
    );

    if (confirmDelete) {

        equipmentList = equipmentList.filter(function(item) {
            return item.id !== id;
        });

        saveData();

        displayEquipment();

        alert("Equipment record deleted!");
    }
}


// ======================================
// RESET FORM
// ======================================

function resetForm() {

    equipmentForm.reset();

    editingId = null;

    formTitle.textContent = "Add New Equipment";

    saveButton.textContent = "Add Equipment";

    cancelButton.classList.add("hidden");
}


// Cancel editing
cancelButton.addEventListener("click", function() {
    resetForm();
});


// ======================================
// SEARCH AND FILTER
// ======================================

searchInput.addEventListener("input", displayEquipment);

conditionFilter.addEventListener("change", displayEquipment);

categoryFilter.addEventListener("change", displayEquipment);

sortFilter.addEventListener("change", displayEquipment);


// ======================================
// EXPORT CSV REPORT
// ======================================

function exportCSV() {

    if (equipmentList.length === 0) {
        alert("There are no records to export.");
        return;
    }

    const headers = [
        "Equipment ID",
        "Equipment Name",
        "Category",
        "Quantity",
        "Condition",
        "Location",
        "Purchase Date",
        "Person In Charge"
    ];

    const rows = equipmentList.map(function(item) {

        return [
            item.id,
            item.name,
            item.category,
            item.quantity,
            item.condition,
            item.location,
            item.purchaseDate,
            item.personInCharge
        ];
    });

    // Prepare CSV information
    function csvValue(value) {
        return '"' + String(value).replace(/"/g, '""') + '"';
    }

    const csvContent = [
        headers,
        ...rows
    ].map(function(row) {
        return row.map(csvValue).join(",");
    }).join("\r\n");

    // Create downloadable file
    const blob = new Blob(
        ["\uFEFF" + csvContent],
        { type: "text/csv;charset=utf-8;" }
    );

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");

    link.href = url;
    link.download = "Computer_Lab_Equipment_Report.csv";

    document.body.appendChild(link);

    link.click();

    link.remove();

    URL.revokeObjectURL(url);
}


// ======================================
// PRINT REPORT
// ======================================

function printReport() {
    window.print();
}


// ======================================
// INITIAL DISPLAY
// ======================================

displayEquipment();
